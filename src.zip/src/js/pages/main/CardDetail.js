import React from 'react';
 
 
 import "./Card_detail.css";
 import room2 from "../../images/adds/room2.jpg";

import Carousels from "../../components/Carousels";



const CardDetail = () => {
    return (
   
        <div className="card_detail">
        <div class="container">
            <div class="row">
                <div class="col-1 d-flex align-items-center justify-content-center">
                    <span><i class="fa fa-home nav-icon-size"></i></span>
                </div>
                <div class="col-1 ">
                    <div class="details-title">
                        1BHK - Balcony - Baba Market
                    </div>
                    <div class="details-sub-title">
                        Pintopark, Morar, Gwalior, M.P.
                    </div>
                </div>
                <div class="col-1 ">
                    <div class="details-title">
                        <span><i class="fas fa-rupee-sign"></i></span> 15,000/Month
                    </div>
                    <div class="details-sub-title">
                        Non-Negogotiable
                    </div>
                </div>
                <div class="col-1">
                    <div class="details-title">
                        560
                    </div>
                    <div class="details-sub-title">
                        sq.Ft
                    </div>
                </div>
                <div class="col-1 ">
                    <div class="details-title">
                        <span><i class="fas fa-rupee-sign"></i></span>10,000

                    </div>
                    <div class="details-sub-title ">
                        Deposit
                    </div>
                </div>
                <div class="col ">
                    <button className="btn">Owner Details</button>
                </div>
                {/* <div class="col-1 d-flex flex-column align-items-center justify-content-center ">
                    <span><i class="fa fa-heart nav-icon-size"></i></span>
                </div> */}
            </div>
            <br></br>
            </div>
            <div className="room_photo">
            <img src={room2} />
           
            </div>
            <br></br>
            <br></br>
        




            
            <div class="container">
            <div class="overview-title">
                <h1>Overview</h1>
            </div>
            <hr className="hr"></hr>
            <div class="row">
                <div
                    class="col-d">
                    <label className="label"> Furniture Status</label>
                    {/* <span>Semi / Fully Furniture</span> */}
                </div>
                
                <div
                    class="col-d">
                   <label className="label">Facing</label>
                    {/* <span>East</span> */}
                </div>
            </div>
            <div className="row">
                <div
                    class="col-d">
                    <label className="label">Water Supply</label>
                    {/* <span>BoreWell / Corporation</span> */}
                </div>
               
                <div
                    class="col-d">
                    <label className="label">Floor</label>
                    {/* <span>1/3</span> */}
                </div>
                </div>
                <div className="row">
                <div
                    class="col-d">
                    <label className="label">Bathroom               </label>
                    {/* <span>1</span> */}
                </div>
                
                <div class="col-d">
                <label className="label">            Gated Security</label>
                    {/* <span>No</span> */}
                </div>
               </div>
               <div className="row">
                <div
                    class="col-d">
                    <label className="label">Non-veg allowed</label>
                    {/* <span>No</span> */}
                </div>
            </div>
        </div>
            </div>
            

        
           
        
        
        
 
   
    )
}

export default CardDetail
