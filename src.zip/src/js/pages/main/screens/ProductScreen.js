
import React from "react";
import { Link } from "react-router-dom";
import data from "../../../Data";
import "./Product_Screen.css";

import { IoArrowBackCircle } from "react-icons/io5";

const ProductScreen = (props) => {
  const singleProduct = data.products.find(
    (item) => item._id === props.match.params.id
  );
  const {
    name,
    image,
   
    description,
    
    address,
    deposit,
      sqFt,
      preffered_Tenant,
      posted_on,
      parking,
      nonNegogotiable,
      possession,
      food_facility,
      furniture_status,
      water_supply,
      bathroom,
      non_veg,
      facing,
      floor,
      amenities,
      gatedSecurity,
  } = singleProduct;
  return (
    <div className="container py-1 ">
      <Link to="/products" className="goback-link">
        <h3 className="flexBox ">
          <IoArrowBackCircle />
          <span>Back</span>
        </h3>
      </Link>

      <>
      <article className="single-product-info"> 
      
      <div className="container">
      <div className="row">
      <div class="col-1 ">
                    <div class="details-title">
                        {name}
                    </div>
                    <div class="details-sub-title">
                        {address}
                    </div>
                    </div>
                    <div class="col-1 ">
                    <div class="details-title">
                        <span><i class="fas fa-rupee-sign"></i></span> {nonNegogotiable}
                    </div>
                    <div class="details-sub-title">
                        Non-Negogotiable
                    </div>
                </div>
                <div class="col-1">
                    <div class="details-title">
                        {sqFt}
                    </div>
                    <div class="details-sub-title">
                        sq.Ft
                    </div>
                </div>
                <div class="col-1 ">
                    <div class="details-title">
                        <span><i class="fas fa-rupee-sign"></i></span>{deposit}

                    </div>
                    <div class="details-sub-title ">
                        Deposit
                    </div>
                </div>
                <div class="col ">
                    <button className="btn">Owner Details</button>
                </div>
                
            </div>
            
            
           
                    
        <div className="single-product">
        <img src={image}/>
          {/* <img src={image} alt={name} className="single-product-img" /> */}
        </div>
        <br></br>


        <div className="single-room-info">
            <article className="desc">
              <h1>details</h1>
              <p>{description}</p>
            </article>
            <article className="info">
              <h3>info</h3>
              <h6>Preffered Teanant : {preffered_Tenant}</h6>
              <h6>Posted On : {posted_on} </h6>
              <h6>Parking : {parking} </h6>
              <h6>Possesion : {possession} </h6>
              <h6>Food Facility : {food_facility} </h6>
              
              
            </article>
          </div>
          <div className="overview-info">
            <article className="overview">
            <h2>Overview</h2>
            <h4>Furniture Status:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {furniture_status}</h4>
            <h4>Facing: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {facing}</h4>
            <h4>Floor: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{floor}</h4>
            <h4> Water_Supply: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {water_supply}</h4>
            <h4>Bathroom: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{bathroom}</h4>
            <h4>NonVegAllowed:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{non_veg}</h4>
            <h4>GatedSecurity:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{gatedSecurity}</h4>
            <br></br>
            


            </article>
            <br></br>
          </div>
          
          <section className="room-amenities">
          <h2>Amenities</h2>
          <ul className="amenities">
            {amenities.map((item, index) => (
              <li key={index}>- {item}</li>
            ))}
          </ul>
        </section>
        <div className="action-section ">
            <button className="btn app">Appointment</button>&nbsp;&nbsp;&nbsp;&nbsp;
            <button className="btn chat">Chat With Owner</button>
          </div>
       
       
           
           
         
        
        
          </div>
          
          
        
        
        
     
      
    
    </article>
    </>
    </div>
  );
};

export default ProductScreen;

// class ProductScreen extends React.Component{
//   constructor(props){
//     super(props);
//     this.state={};
//   }
//   render() {
//     return(
//       <div>
         
//       </div>
//     )
//   }
// }