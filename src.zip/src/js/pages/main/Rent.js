import React,{useState, useEffect} from 'react'
import axios from 'axios'
// import "./bootstrap.css";
import pic from '../../images/adds/pic.png'
import { useParams } from 'react-router'
import image44 from '../../images/adds/image44.png'
import image33 from '../../images/adds/image33.png'
import {AiTwotoneHome} from "react-icons/ai";
import {BsWifi} from "react-icons/bs";
import {GiLift} from "react-icons/gi";
import {MdFavoriteBorder} from "react-icons/md";
import {CgGym} from "react-icons/cg";
import {FiShare2} from "react-icons/fi";
import {GoLocation} from "react-icons/go";
import ac from '../../images/adds/ac.png';

// import "./Card_detail.css";
import "./Rent.css";
import RentCarousels from '../../components/RentCarousels'

function Rent() {
    const {id} = useParams()
    const url = `http://localhost:8080/api/getProperty/${id}`
    const [rent, setRent] = useState({
        loading:false,
        data:null,
        error:false

    })



    let content = null

   useEffect(() => {
       setRent({
           loading:true,
           data:null,
           error:false
       })
    axios.get(url)
    .then(response => {
        //setProduct(response.data)
        setRent({
            loading:false,
            data:response.data,
            error:false
        })

    })   
    .catch((error) =>{
        setRent({
            loading:false,
            data:null,
            error:true
        })
    })  
   }, [url])

   if(rent.error){
       <p>
           There is error plz refresh
       </p>
   }

   if(rent.loading){
       content = <p>
           ....loading
       </p>
   }
    if(rent.data){
        
        content =

        <div className="conatiner1"> 
        <div class="rent-heading">
            <h1 className="heading" >
            {/* {rent.data.apartmentName} */} 
           <AiTwotoneHome/> {rent.data.apartmentName}
            </h1>
            
            <div className="location">
            <GoLocation/> {rent.data.street} {rent.data.city}
            <span className="rent">${rent.data.expectedRent}/month</span>
            <ul className="sale">For Sale</ul>
            </div>
            
            </div>
           <div className="picture">
           <RentCarousels/>  

           </div>
            {/* */}
           
            {/* <div className="rent-display">  */}
            
           
            {/* <div className="row">
            <div className="col">
                <img 
                src={pic}/>
            </div>
            <div className="col">
            <img src={image44}/>

            </div> */}
            {/* <div className="col">
            <img src={image33}/>

            </div> */}
            {/* </div> */}
            {/* </div> */}

            <div className="box7">
            <div class="container">
            <div class="row">
                
                <div class="col-1 ">
                    <div class="details-title">
                        {/* 1BHK - Balcony - Baba Market */}
                        {rent.data.apartmentName}
                    </div>
                    <div class="details-sub-title">
                        {/* Pintopark, Morar, Gwalior, M.P. */}
                        {/* {rent.data.street}  */}
                        {rent.data.city}
                    </div>
                </div>
                <div class="col-1 ">
                    <div class="details-title">
                        <span><i class="fas fa-rupee-sign"></i></span> Rs {rent.data.expectedRent}/Month
                    </div>
                    <div class="details-sub-title">
                    {rent.data.negotiable}
                        {/* Non-Negogotiable */}
                    </div>
                </div>
                <div class="col-1">
                    <div class="details-title">
                        {/* 560 */}
                        {rent.data.propertySize}
                    </div>
                    <div class="details-sub-title">
                        sq.Ft
                    </div>
                </div>
                <div class="col-1 ">
                    <div class="details-title">
                        <span><i class="fas fa-rupee-sign"></i></span>
                        {/* 10,000 */}
                      Rs  {rent.data.expectedDeposit}

                    </div>
                    <div class="details-sub-title ">
                        Deposit
                    </div>
                </div>
                <div class="col-1 ">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <button className="btn2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Owner Details&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button>
                </div>
                {/* <div class="col-1 d-flex flex-column align-items-center justify-content-center ">
                    <span><i class="fa fa-heart nav-icon-size"></i></span>
                </div> */}
            </div>
            <br></br>
            </div>

            </div>
            <br></br>
            <br></br>
{/* ***********************************************************************************************/}

<div className="box4">
    <div className="title">
    Overview

    </div>
    <br></br>
    <hr className="hr"></hr>
    <div className="row">
        <div className="col">
        <div class="details-title">
                        
                        {rent.data.apartmentType}
                    </div>
                    <div class="details-sub-title">
                        
                        Property Type
                    </div>

        </div>
        <div className="col">
        <div class="details-title">
                        
                        {rent.data.bhkType}
                    </div>
                    <div class="details-sub-title">
                        
                       BHK
                    </div>

        </div>
        <div className="col">
        <div class="details-title">
                        
                        {rent.data.bathroom}
                    </div>
                    <div class="details-sub-title">
                        
                        Bathroom
                    </div>

        </div>
        <div className="col">
        <div class="details-title">
                        
                        {rent.data.propertySize}
                    </div>
                    <div class="details-sub-title">
                        
                        Sqft
                    </div>

        </div>
        <div className="col">
        <div class="details-title">
                        
                        {rent.data.propertyAge}
                    </div>
                    <div class="details-sub-title">
                        
                        Property Age
                    </div>

        </div>
    </div>
</div>
<br></br>
<br></br>
<div className="box6">
<div className="title">
    Description

    </div>
    <br></br>
    <hr className="hr"></hr>
    Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. 
    Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.
<br></br>
Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius.
 Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.
</div>
<br></br>
<br></br>
<div className="box4">
    <div className="title">
    Details

    </div>
    <br></br>
    <hr className="hr"></hr>
    <div className="row">
        <div className="col">
            <span className="detail">Expected Deposit : </span>
            <span className="sub-detail">$ {rent.data.expectedDeposit}</span>
        </div>
        <div className="col">
            <span className="detail">Parking : </span>
            <span className="sub-detail"> {rent.data.parking}</span>
        </div>
    </div>
    <div className="row">
        <div className="col">
        &nbsp;&nbsp;&nbsp;&nbsp; <span className="detail">Property Size : </span>
            <span className="sub-detail"> {rent.data.propertySize}</span>
        </div>
        <div className="col">
            <span className="detail">Property Age : </span>
            <span className="sub-detail"> {rent.data.propertyAge}</span>
        </div>
    </div>
    <div className="row">
        <div className="col">
        &nbsp;&nbsp;&nbsp;&nbsp;  <span className="detail">Bathroom : </span>
            <span className="sub-detail"> {rent.data.bathroom}</span>
        </div>
        <div className="col">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span className="detail">Balcony : </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <span className="sub-detail"> {rent.data.balcony}</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        </div>
    </div>
    <div className="row">
        <div className="col">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <span className="detail">Facing : </span>
            <span className="sub-detail">{rent.data.facing}</span>
        </div>
        <div className="col">
            <span className="detail">Floor : </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <span className="sub-detail"> {rent.data.floor}</span>
        </div>
    </div>
    <div className="row">
        <div className="col">
        &nbsp;&nbsp; <span className="detail">Preferd Tenants : </span>
            <span className="sub-detail">{rent.data.preferdTenants}</span>
        </div>
        <div className="col">
            <span className="detail">Furnishing : </span>
            <span className="sub-detail"> {rent.data.furnishing}</span>
        </div>
    </div>
    </div>
    <br></br>
    <br></br>
    <div className="box9">
    <div className="title">
    Amenities

    </div>
    <br></br>
    <hr className="hr"></hr>
    <div className="row">
        <div className="col">
        <div class="details-title">
        <CgGym size={30}/> 
                        
                    </div>
                    <div class="details-sub-title">
                    {rent.data.gym}Gym
                    </div>

            
        </div>
        <div className="col">
        <div class="details-title">
        <BsWifi size={30}/> 
                        
                    </div>
                    <div class="details-sub-title">
                    {rent.data.internet}
                    </div>

            
        </div>
        <div className="col">
        <div class="details-title">
        <GiLift size={30}/> 
                        
                    </div>
                    <div class="details-sub-title">
                    {rent.data.lift}
                    </div>

            
        </div>
        <div className="col">
        <div class="details-title">
        <CgGym size={30}/> 
                        
                    </div>
                    <div class="details-sub-title">
                    {rent.data.ac}
                    </div>

            
        </div>
    </div>

    </div>




{/* *************************************************************************************** */}
                 {/* <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 p-4 order-2 d-flex align-items-center justify-content-between flex-column border">
                    <div class="row mb-3">
                        <div class="col-6 d-flex justify-content-between align-items-center border ">
                            <div class="d-flex justify-content-center align-items-center">
                                <i class="fas fa-user fa-icons"></i>
                            </div>
                            <div class=" d-flex flex-column align-items-start justify-content-center p-2">
                                <div class="">
                                    <h6>{rent.data.preferdTenants}</h6>
                                </div>
                                <div><small class="small">Preffered Tenant&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</small></div>
                            </div>
                        </div>
                        <div class="col-6 d-flex justify-content-between align-items-center border ">
                            <div class="d-flex justify-content-center align-items-center">
                               
                            </div>
                            <div class=" d-flex flex-column align-items-start justify-content-center p-2">
                                <div class="">
                                    <h6>Sep 20,2020</h6>
                                </div>
                                <div><small class="small">Posted On&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</small></div>
                            </div>
                        </div>
                        <div class="col-6 d-flex justify-content-between align-items-center border ">
                            <div class="d-flex justify-content-center align-items-center">
                                <i class="fa fa-car fa-icons" aria-hidden="true"></i>
                            </div>
                            <div class=" d-flex flex-column align-items-start justify-content-center p-2">
                                <div class="">
                                    <h6>{rent.data.parking}</h6>
                                </div>
                                <div><small class="small">Parking&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</small></div>
                            </div>
                        </div>
                        <div class="col-6 d-flex justify-content-between align-items-center border ">
                            <div class="d-flex justify-content-center align-items-center">
                                <i class="fas fa-clock-o fa-icons"></i>
                            </div>
                            <div class=" d-flex flex-column align-items-start justify-content-center p-2">
                                <div class="">
                                    <h6>{rent.data.propertyAge}</h6>
                                </div>
                                <div><small class="small">Property Age&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</small></div>
                            </div>
                        </div>
                        <div class="col-6 d-flex justify-content-between align-items-center border ">
                            <div class="d-flex justify-content-center align-items-center">
                                <i class="fas fa-clock-o fa-icons"></i>
                            </div>
                            <div class=" d-flex flex-column align-items-start justify-content-center p-2">
                                <div class="">
                                    <h6>{rent.data.bhkType}</h6>
                                </div>
                                <div><small class="small">BHK Type&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</small></div>
                            </div>
                        </div>
                        <div class="col-6 d-flex justify-content-between align-items-center border ">
                            <div class="d-flex justify-content-center align-items-center">
                                <i class="fas fa-key fa-icons"></i>
                            </div>
                            <div class=" d-flex flex-column align-items-start justify-content-center p-2">
                                <div class="">
                                    <h6>{rent.data.totalFloor}</h6>
                                </div>
                                <div><small class="small">Total Floor&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</small></div>
                            </div>
                        {/* </div>
                        </div> */}                    
                      {/* </div> */} 
                      {/* <div className="container">

<div className="row">
    <div className="col">
        <button className="btn">&nbsp;&nbsp;&nbsp;&nbsp;Appointment&nbsp;&nbsp;&nbsp;&nbsp;</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    </div>
    <div className="col">
        <button className="btn">Chat with owner</button>
    </div>

</div>
</div>
                    
                    </div>
                    
                   
</div>
                    <hr className="hr"></hr>

                    <div class="container">
            <div class="overview-title">
                <h1 className="heading2">Overview</h1>
            </div>
            <hr className="hr"></hr>
            <div class="row d-flex justify-content-between align-items-center">
                <div
                    class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 d-flex justify-content-between align-items-center mb-3">
                    <span className="view"><i class="fas fa-couch"></i> Furniture Status</span>
                    <span className="overview">{rent.data.furnishing}</span>
                </div>
                <div
                    class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12  d-flex justify-content-between align-items-center mb-3">
                    <span className="view"> Facing</span>
                    <span className="overview">{rent.data.facing}</span>
                </div>
                <div
                    class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12  d-flex justify-content-between align-items-center mb-3">
                    <span className="view"><i class="fas fa-faucet"></i> Water Supply</span>
                    <span className="overview">{rent.data.waterSupply}</span>
                </div>
                <div
                    class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12  d-flex justify-content-between align-items-center mb-3">
                    <span className="view"><i class="fas fa-building"></i> Floor</span>
                    <span className="overview">{rent.data.floor}</span>
                </div>
                <div
                    class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 d-flex justify-content-between align-items-center mb-3">
                    <span className="view"><i class="fas fa-bath"></i> Bathroom</span>
                    <span className="overview">{rent.data.bathroom}</span>
                </div>
                <div
                    class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 d-flex justify-content-between align-items-center mb-3">
                    <span className="view"> Gated Security</span>
                    <span className="overview">{rent.data.gatedSecurity}</span>
                </div>
                
                <div
                    class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 d-flex justify-content-between align-items-center mb-3">
                    <span className="view"> Non Veg Allowed</span>
                    <span className="overview">{rent.data.nonVeg}</span>
                </div>
            </div>
        
        </div> 
        <hr className="hr"></hr>

        <div class="container">
            <h1 className="heading2">Description</h1>
            <hr className="hr"></hr>
            <p class="px-2">{rent.data.description}
            </p>

            {/* <div class="text-center readMoreBtn" id="readMoreBtn">
                <div>Read More</div>
                <div><i class="fas fa-angle-down rmAnim"></i></div>
            </div> */}

        {/* </div>
        <hr className="hr"></hr>
        <div class="container">
            <div class="overview-title">
                <h1 className="heading2">Amenities</h1>
            </div>
            <hr className="hr"></hr>
            <div class="row ">
                
                    <div class="col  ">
                     */}
                        {/* <span><i class="fas fa-helicopter"></i> {rent.data.gym}</span>
                        <hr class="hr1"></hr>
                    </div>
                    <div class="col">
                        <span><i class="fas fa-dumbbell"></i> {rent.data.lift}</span>
                        <hr class="hr1"></hr>
                    </div>
                    <div class="col">
                        <span><i class="fas fa-wifi"></i> {rent.data.internet}</span>
                        <hr class="hr1"></hr>
                    </div>
                       </div>
     
       </div> */}
       {/* <div class="row ">
                
                    <div class="col  ">
                        <span><i class="fas fa-helicopter"></i> {rent.data.ac}</span>
                        <hr class="hr1"></hr>
                    </div>
                    <div class="col">
                        <span><i class="fas fa-dumbbell"></i> Gym</span>
                        <hr class="hr1"></hr>
                    </div>
                    <div class="col">
                        <span><i class="fas fa-wifi"></i> Wifi</span>
                        <hr class="hr1"></hr>
                    </div>
                       </div>
                       <div class="row "> */}
                
                    {/* <div class="col  ">
                        <span><i class="fas fa-helicopter"></i> Lift</span>
                        <hr class="hr1"></hr>
                    </div>
                    <div class="col">
                        <span><i class="fas fa-dumbbell"></i> Gym</span>
                        <hr class="hr1"></hr>
                    </div>
                    <div class="col">
                        <span><i class="fas fa-wifi"></i> Wifi</span>
                        <hr class="hr1"></hr>
                    </div>
                       </div>
                       <hr className="hr"></hr> */} 

                      

       
    
                    
                    



                    
                    





{/* ********************************************************************************************************* */}
            
            
        </div>
//********************************************************************************************************* */


{/* /************************************image slider*************************************************** */ }

{/* **************************************end image slider************************************************************** */}

//****************************************************************************************************** */
    }
    return (
        <div>
             {content}
            </div>

    )
}

export default Rent
