import React, { Component } from 'react'
import { useHistory, useParams } from 'react-router-dom'
import axios from 'axios'

class AxiosTable extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             Hostel: [],
        }
    }
   
        
    
    componentDidMount(){
        axios.get("http://localhost:8082/api/getHostel")
      
        .then(response =>{
            console.log(response)
            this.setState({Hostel: response.data})
           return response.json(); 
        

        })
        .catch(error => {
            console.log(error)
        })
    }
    // hostelPageAndGenres =(id, element)=> {
    //     axios.get("http://localhost:8082/api/getHostel/{id}")
    //     .then(response => response.json())
    //     .then(data => {
    //         element.geners = data.genres;

    //     })
    // }
    
    // SingleProject = (props) => {
    //     const { id } = props.match.params
    //     const singleProduct = props.match.params.id
        
    //       const {
           
    //           city,
    //           street,
    //           food,
    //           parking,
    //       } = singleProduct;
    //     }
    viewHostelDetail = (event)=>{
        event.preventDefault();

        axios.get("http://localhost:8082/api/getHostel/",event.target.value)
    }
    
    render() {
        const {Hostel}=this.state
       
        return (
            <div>
                List of property 
                {
                    
                   // Hostel.map(hostel => <div key={hostel.id}>{hostel.title}</div>) 
                     Hostel.map(hostel => {
                         const{id,city,street,food,parking}=hostel;
                         return(
                            <form action="" >
                                <input name="id" type="hidden" value={id}></input>
                                <button onClick = {this.viewHostelDetail}class="btn1" > View
            
            </button>
                            </form>
                             
                             
                            /* <div>
                             <p>City:{city}</p>
                             <p>Street:{street}</p>
                             <p>Food:{food}</p>
                             <p>Laundry:{parking}</p>
                             <hr className="hr"></hr>
                             
                             </div>
                              */
                         )
                     })
                }

            </div>
        )
    }
}
export default AxiosTable
