

import React from 'react'
import { Link } from 'react-router-dom'
import image33 from '../images/adds/image33.png'
import "../components/Productcard.css"

function ProductCard(props) {
  return (
    <div className="productdetail">
   

    
    {/* <Link to={`/products/${props.product.id}`}>
    <div className="image1">
    <div 
    style={{
      width: "100%", height: "300px" ,marginInlineStart:"15%", marginBottom:"10%", 
      backgroundImage:`url(${room1})`,
      
    }}
    // className="w-50% h-64 bg-blue bg-cover"
    
    >
    </div>
    <div className="p3">
      <h3 className="picdetail">
      <Link to={`/products/${props.product.id}`}>
        {props.product.street} {props.product.city}
      </Link>
      </h3>
      <div className="picdetail">
        Rent:- Rs {props.product.expectedRent}
      </div>
      <Link to={`/products/${props.product.id}`}>
        <button className="btn8">View</button>
      </Link>
    </div>
    </div>
    </Link>
     */}
     <div className="image2">
       <div className="box">
       <div 
    style={{
      width: "100%", height: "300px", marginBottom:"10%", display:"block", object:"cover",
 
         backgroundImage:`url(${image33})`,
      
    }}>
    </div>
    
    <div className="text">
      <h3>{props.product.street} {props.product.city}</h3>
      <span>${props.product.expectedRent}/month</span>
      {/* <p>{props.rent.description}</p> */}
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vehicula eros odio, a ultricies velit varius sit amet.</p>
    </div>
    <div className="details">
      <span>{props.product.wifi}   </span>
      <span>  {props.product.lift} </span>
      <span>{props.product.tv }</span>
      <span>{props.product.mess}</span>
    </div>
    <Link to={`/products/${props.product.id}`} className="link">
      More Details
    </Link>
       </div>
     </div>


    

    
   
    </div>
    
  )}
export default ProductCard
