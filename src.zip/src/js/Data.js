


import pic from "./images/adds/pic.png";
import pic2 from "./images/adds/pic2.png";



import image11 from "./images/adds/image11.png";
import image22 from "./images/adds/image22.png";
import image33 from "./images/adds/image33.png";
import image44 from "./images/adds/image44.png";
import room1 from "./images/adds/room1.jpg";
import room2 from "./images/adds/room2.jpg";

export const data =[image11, image22, image33, image44,room1, room2];

  


// const data = {
//   products: [
   
//     {
//       _id: "1",
//       name: "RPR01 Pinto Park(Males only)",
//       address: "PintoPark, Morar, Gwalior, (M.P.)",
//       image: image44,
//       deposit: 10000,
//       sqFt: 560,
//       nonNegogotiable:"15000/month",
//       preffered_Tenant: "Any",
//       posted_on:"15 May",
//       parking:"Bike and Car",
//       possession:"Immediately",
//       food_facility:"Yes",
//       furniture_status:"Semi/FullyFurniture",
//       water_supply:"BoreWell/Corporation",
//       bathroom:1,
//       non_veg:"No",
//       facing:"east",
//       floor:"1/3",
//       gatedSecurity:"No",
//       amenities:["Lift","Gym","Wifi","Air Conditioner","Club House","Non Veg Allowed"],
//       description:
//         "Street art edison bulb gluten-free, tofu try-hard lumbersexual brooklyn tattooed pickled chambray. Actually humblebrag next level, deep v art party wolf tofu direct trade readymade sustainable hell of banjo. Organic authentic subway tile cliche palo santo, street art XOXO dreamcatcher retro sriracha portland air plant kitsch stumptown. Austin small batch squid gastropub. Pabst pug tumblr gochujang offal retro cloud bread bushwick semiotics before they sold out sartorial literally mlkshk. Vaporware hashtag vice, sartorial before they sold out pok pok health goth trust fund cray.",
      
     
//       deals: true,
//     },
    
    
//   ],
// };

//main product data here
 export default data;

// carousel sliders here

export const carouselSliders = [
  {
    id: "1",
    sliderImage: image11,
    title: "First slide label",
    subTitle: "Nulla vitae elit libero, a pharetra augue mollis interdum.",
    
    
  },
  {
    id: "2",
    sliderImage: image22,
    title: "Second slide label ",
    subTitle: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. ",
    
  },
  {
    id: "3",
    sliderImage: image33,
    title: "Third slide label",
    subTitle: "Praesent commodo cursus magna, vel scelerisque nisl consectetur.",
    
  },
  {
    id: "4",
    sliderImage: image44,
    title: "Fourth slide label",
    subTitle: "Praesent commodo cursus magna, vel scelerisque nisl consectetur.",
    
  },
];



